// Function for the image gallery
function changeImage(src) {
    document.getElementById('displayed-image').src = src;
}

// Automatic slideshow doesn't need JavaScript with this CSS-only approach
// The animation is handled entirely by CSS