
// Color changing button
document.getElementById('colorButton').addEventListener('click', function() {
  this.style.backgroundColor = this.style.backgroundColor === 'orange' ? 'green' : 'orange';
});

// Greeting based on current time
function showGreeting() {
  const hours = new Date().getHours();
  let greeting;

  if (hours < 12) {
    greeting = "Good Morning!";
  } else if (hours < 18) {
    greeting = "Good Afternoon!";
  } else {
    greeting = "Good Evening!";
  }

  alert(greeting);
}

// Calculator
function addNumbers() {
  const num1 = parseFloat(document.getElementById('num1').value);
  const num2 = parseFloat(document.getElementById('num2').value);
  const result = num1 + num2;

  document.getElementById('calcResult').textContent = "Result: " + result;
}
